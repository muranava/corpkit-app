"""

=================
How to Find Stuff
=================

How to find things in NumPy.

"""
from __future__ import division, absolute_import, print_function
